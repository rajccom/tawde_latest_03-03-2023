ALTER TABLE `sms_templates` ADD COLUMN IF NOT EXISTS `template_id` VARCHAR(100) NULL AFTER `sms_body`;

INSERT INTO `sms_templates` (`id`, `identifier`, `sms_body`, `template_id`, `status`, `created_at`, `updated_at`) 
VALUES
(null, 'profile_picture_view_request', '<p>Hi [[name]], [[member_name]] has sent you profile picture view request. [[url]]</p>', NULL, 1, '2021-12-14 10:16:13', '2021-12-14 10:52:07'),
(null, 'profile_picture_view_request_accepted', '<p>Hi [[name]], [[member_name]] has accepted your profile picture view request. [[url]]</p>', NULL, 1, '2021-12-14 10:16:45', '2021-12-14 10:52:12'),
(null, 'gallery_image_view_request', '<p>Hi [[name]], [[member_name]] has sent you gallery image view request. [[url]]</p>', NULL, 1, '2021-12-14 10:17:12', '2021-12-14 10:52:15'),
(null, 'gallery_image_view_request_accepted', '<p>Hi [[name]], [[member_name]] has accepted your gallery image view request. [[url]]</p>', NULL, 1, '2021-12-14 10:17:12', '2021-12-14 10:52:02');

COMMIT;